package com.compi.compi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PauApplicationTests {

	@Test
	void contextLoads() {
	}

}
